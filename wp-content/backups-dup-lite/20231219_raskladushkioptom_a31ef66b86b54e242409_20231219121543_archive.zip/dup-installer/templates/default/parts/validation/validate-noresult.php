<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="validate-no-result" class="text-center" >
    <i class="far fa-check-circle"></i> 
    Pending setup validation!<br/>
    Click the validate button to continue...
</div>